# Fournix AI Android

Cette version Android :
- retire l'intégration PayDunya (élément 8) ;
- utilise l'identité visuelle bleu + rouge ;
- conserve l'interface Fournix et le profil ;
- fonctionne comme application Android via WebView.

Pour générer l'APK : ouvrir ce dossier dans Android Studio puis Build > Build APK(s).
Le fichier APK sera généré dans app/build/outputs/apk/debug/ après compilation.
